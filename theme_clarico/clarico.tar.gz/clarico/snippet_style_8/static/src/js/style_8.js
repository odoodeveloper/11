/*$(window).load(function() {
	 $(".text_area_div").fadeTo('slow',1.0).css("transform","translate(-3em,0)");
	 $(".slide1_img1_div").fadeTo('slow',1.0).css("transform","translate(0,-3em)");
});
*/